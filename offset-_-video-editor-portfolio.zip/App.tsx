
import React, { useState, useEffect, Suspense } from 'react';
import Navbar from './components/Navbar';
import Hero from './components/Hero';
import Projects from './components/Projects';
import Shorts from './components/Shorts';
import Contact from './components/Contact';
import LoadingScreen from './components/LoadingScreen';
import VideoModal from './components/VideoModal';
import { Project } from './types';

const App: React.FC = () => {
  const [loading, setLoading] = useState(true);
  const [activeVideo, setActiveVideo] = useState<string | null>(null);

  useEffect(() => {
    // Simulate initial page load sequence
    const timer = setTimeout(() => {
      setLoading(false);
    }, 2000);
    return () => clearTimeout(timer);
  }, []);

  const handleOpenVideo = (videoUrl: string) => {
    setActiveVideo(videoUrl);
  };

  if (loading) return <LoadingScreen />;

  return (
    <div className="relative bg-black min-h-screen selection:bg-cyan/30 selection:text-cyan-bright">
      {/* Background Orbs */}
      <div className="fixed inset-0 overflow-hidden pointer-events-none z-0">
        <div 
          className="absolute top-[-10%] right-[-5%] w-[800px] h-[800px] rounded-full blur-[140px] opacity-[0.08] animate-float"
          style={{ background: 'radial-gradient(circle, #0F1928 0%, transparent 70%)' }}
        />
        <div 
          className="absolute bottom-[-10%] left-[-5%] w-[800px] h-[800px] rounded-full blur-[160px] opacity-[0.06] animate-float-reverse"
          style={{ background: 'radial-gradient(circle, #06B6D4 0%, transparent 70%)' }}
        />
      </div>

      <Navbar />

      <main className="relative z-10">
        <Hero />
        <Projects onOpenVideo={handleOpenVideo} />
        <Shorts onOpenVideo={handleOpenVideo} />
        <Contact />
      </main>

      <footer className="relative z-10 py-20 flex flex-col items-center gap-4 text-textSecondary text-[12px] uppercase tracking-[0.1em]">
        <div className="w-12 h-[1px] bg-white/10 mb-4" />
        <p>© 2024 .Offset — Video Editing Portfolio</p>
      </footer>

      {activeVideo && (
        <VideoModal videoUrl={activeVideo} onClose={() => setActiveVideo(null)} />
      )}

      <style>{`
        @keyframes float {
          0% { transform: translate(0, 0) scale(1); }
          50% { transform: translate(30px, -30px) scale(1.05); }
          100% { transform: translate(0, 0) scale(1); }
        }
        @keyframes float-reverse {
          0% { transform: translate(0, 0) scale(1); }
          50% { transform: translate(-40px, 20px) scale(1.1); }
          100% { transform: translate(0, 0) scale(1); }
        }
        .animate-float {
          animation: float 45s ease-in-out infinite alternate;
        }
        .animate-float-reverse {
          animation: float-reverse 45s ease-in-out infinite alternate;
        }
      `}</style>
    </div>
  );
};

export default App;
