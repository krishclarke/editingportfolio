
import { Project, Short, Tool } from './types';

export const PROJECTS: Project[] = [
  {
    id: 'p1',
    number: '01',
    title: 'Anime Edit 1',
    description: 'High paced + smooth transitions',
    software: 'After Effects',
    thumbnail: 'https://picsum.photos/id/1/800/450',
    videoUrl: 'https://www.youtube.com/embed/dQw4w9WgXcQ'
  },
  {
    id: 'p2',
    number: '02',
    title: 'Cartoon Explainer',
    description: 'Dynamic motion graphics for YouTube',
    software: 'Premiere Pro',
    thumbnail: 'https://picsum.photos/id/10/800/450',
    videoUrl: 'https://www.youtube.com/embed/dQw4w9WgXcQ'
  },
  {
    id: 'p3',
    number: '03',
    title: 'Crime Documentary',
    description: 'Moody, high-tension storytelling',
    software: 'Premiere Pro',
    thumbnail: 'https://picsum.photos/id/20/800/450',
    videoUrl: 'https://www.youtube.com/embed/dQw4w9WgXcQ'
  },
  {
    id: 'p4',
    number: '04',
    title: 'Anime What If',
    description: 'Fast-cut narrative sequence',
    software: 'After Effects',
    thumbnail: 'https://picsum.photos/id/30/800/450',
    videoUrl: 'https://www.youtube.com/embed/dQw4w9WgXcQ'
  }
];

export const SHORTS: Short[] = [
  {
    id: 's1',
    title: 'Anime Explainer Short',
    thumbnail: 'https://picsum.photos/id/40/400/711',
    videoUrl: 'https://www.youtube.com/embed/dQw4w9WgXcQ'
  },
  {
    id: 's2',
    title: 'Finance Short',
    thumbnail: 'https://picsum.photos/id/50/400/711',
    videoUrl: 'https://www.youtube.com/embed/dQw4w9WgXcQ'
  },
  {
    id: 's3',
    title: 'Map Animation',
    thumbnail: 'https://picsum.photos/id/60/400/711',
    videoUrl: 'https://www.youtube.com/embed/dQw4w9WgXcQ'
  },
  {
    id: 's4',
    title: 'Character Animation',
    thumbnail: 'https://picsum.photos/id/70/400/711',
    videoUrl: 'https://www.youtube.com/embed/dQw4w9WgXcQ'
  }
];

export const TOOLS: Tool[] = [
  { name: 'Premiere Pro', icon: 'Pr', color: '#9999FF' },
  { name: 'After Effects', icon: 'Ae', color: '#CF96FD' },
  { name: 'Photoshop', icon: 'Ps', color: '#31A8FF' },
  { name: 'GeoLayers', icon: '🌍', color: '#FFFFFF' },
  { name: 'DaVinci Resolve', icon: 'Dr', color: '#FF4B4B' }
];
