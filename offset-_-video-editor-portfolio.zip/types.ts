
export interface Project {
  id: string;
  number: string;
  title: string;
  description: string;
  software: string;
  thumbnail: string;
  videoUrl: string;
}

export interface Short {
  id: string;
  title: string;
  thumbnail: string;
  videoUrl: string;
}

export interface Tool {
  name: string;
  icon: string;
  color: string;
}
