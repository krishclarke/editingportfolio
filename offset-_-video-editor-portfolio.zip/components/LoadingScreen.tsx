
import React from 'react';

const LoadingScreen: React.FC = () => {
  return (
    <div className="fixed inset-0 z-[300] bg-black flex items-center justify-center overflow-hidden">
      <div className="flex items-center animate-logo-intro">
        <span className="text-cyan text-5xl font-bold mr-1">.</span>
        <span className="text-textHead text-5xl font-bold tracking-tight">Offset</span>
      </div>

      <style>{`
        @keyframes logo-intro {
          0% { opacity: 0; transform: scale(0.8); filter: blur(10px); }
          20% { opacity: 1; transform: scale(1.2); filter: blur(0px); }
          40% { transform: scale(1); }
          80% { opacity: 1; transform: scale(1); }
          100% { opacity: 0; transform: scale(1.5); filter: blur(20px); }
        }
        .animate-logo-intro {
          animation: logo-intro 2000ms cubic-bezier(0.16, 1, 0.3, 1) forwards;
        }
      `}</style>
    </div>
  );
};

export default LoadingScreen;
