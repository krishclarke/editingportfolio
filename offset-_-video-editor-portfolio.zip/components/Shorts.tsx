
import React from 'react';
import { SHORTS } from '../constants';
import SectionHeading from './SectionHeading';

interface ShortsProps {
  onOpenVideo: (url: string) => void;
}

const Shorts: React.FC<ShortsProps> = ({ onOpenVideo }) => {
  return (
    <section id="shorts" className="py-32 px-6 md:px-20 max-w-[1440px] mx-auto overflow-hidden">
      <SectionHeading 
        title="Shorts" 
        subtitle="Bite-sized, maximum impact" 
      />

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 w-full mt-20 group/container">
        {SHORTS.map((short) => (
          <div 
            key={short.id}
            onClick={() => onOpenVideo(short.videoUrl)}
            className="group relative aspect-[9/16] rounded-[20px] overflow-hidden cursor-pointer transition-all duration-600 ease-[cubic-bezier(0.16,1,0.3,1)] hover:scale-[1.06] hover:-translate-y-2 hover:shadow-[0_16px_40px_rgba(0,0,0,0.8),0_0_30px_rgba(6,182,212,0.2)] hover:z-20 group-hover/container:opacity-60 group-hover/container:scale-[0.98] hover:!opacity-100 hover:!scale-[1.06]"
          >
            <img 
              src={short.thumbnail} 
              alt={short.title}
              className="absolute inset-0 w-full h-full object-cover brightness-90 group-hover:scale-115 transition-transform duration-1000"
            />
            
            <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/30 to-transparent" />

            <div className="absolute top-4 right-4 px-3 py-1 rounded-full bg-cyan text-[10px] font-bold text-black uppercase tracking-widest z-10 shadow-lg">
              Short
            </div>

            <div className="absolute bottom-0 left-0 w-full p-6 z-10">
              <h4 className="text-[18px] font-semibold text-white leading-tight">
                {short.title}
              </h4>
            </div>

            <div className="absolute inset-0 flex items-center justify-center opacity-0 scale-75 group-hover:opacity-100 group-hover:scale-100 transition-all duration-500">
               <div className="w-[56px] h-[56px] rounded-full glass border-2 border-cyan/50 flex items-center justify-center">
                  <svg className="w-6 h-6 text-white translate-x-1" fill="currentColor" viewBox="0 0 24 24">
                    <path d="M8 5v14l11-7z"/>
                  </svg>
               </div>
            </div>
          </div>
        ))}
      </div>
    </section>
  );
};

export default Shorts;
