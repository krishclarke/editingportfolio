
import React, { useState, useEffect } from 'react';

const Navbar: React.FC = () => {
  const [scrolled, setScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 50);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const scrollToSection = (id: string) => {
    const element = document.getElementById(id);
    if (element) {
      const offset = 80;
      const elementPosition = element.getBoundingClientRect().top;
      const offsetPosition = elementPosition + window.pageYOffset - offset;
      window.scrollTo({
        top: offsetPosition,
        behavior: 'smooth'
      });
      setMobileMenuOpen(false);
    }
  };

  return (
    <nav 
      className={`fixed top-0 left-0 right-0 z-[100] h-[72px] transition-all duration-500 flex items-center justify-center ${
        scrolled ? 'backdrop-blur-[30px] bg-black/85 border-b border-white/10' : 'bg-transparent'
      }`}
    >
      <div className="w-full max-w-[1440px] px-6 md:px-20 flex items-center justify-between">
        {/* Logo */}
        <div 
          className="flex items-center cursor-pointer group"
          onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}
        >
          <span className="text-cyan text-2xl font-bold group-hover:drop-shadow-[0_0_8px_rgba(6,182,212,0.8)] transition-all duration-300">.</span>
          <span className="text-textHead text-2xl font-bold tracking-tight">Offset</span>
        </div>

        {/* Desktop Nav */}
        <div className="hidden md:flex items-center gap-[56px]">
          {['Work', 'Shorts', 'Contact'].map((item) => (
            <button
              key={item}
              onClick={() => scrollToSection(item.toLowerCase())}
              className="relative text-[15px] font-medium text-white/50 hover:text-white transition-colors duration-400 group"
            >
              {item}
              <span className="absolute bottom-[-4px] left-1/2 w-0 h-[1.5px] bg-cyan -translate-x-1/2 group-hover:w-full transition-all duration-400 ease-[cubic-bezier(0.16,1,0.3,1)]" />
            </button>
          ))}
        </div>

        {/* Right CTA */}
        <div className="hidden md:block">
          <button 
            onClick={() => scrollToSection('contact')}
            className="glass px-6 py-2 rounded-full text-[14px] font-semibold text-textHead hover:border-cyan/40 hover:scale-105 transition-all duration-500"
          >
            Get in Touch
          </button>
        </div>

        {/* Mobile Menu Toggle */}
        <button 
          className="md:hidden flex flex-col gap-1.5 p-2"
          onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
        >
          <div className={`w-6 h-[2px] bg-white transition-all ${mobileMenuOpen ? 'rotate-45 translate-y-2' : ''}`} />
          <div className={`w-6 h-[2px] bg-white transition-all ${mobileMenuOpen ? 'opacity-0' : ''}`} />
          <div className={`w-6 h-[2px] bg-white transition-all ${mobileMenuOpen ? '-rotate-45 -translate-y-2' : ''}`} />
        </button>
      </div>

      {/* Mobile Menu Overlay */}
      <div 
        className={`fixed inset-0 bg-black/98 backdrop-blur-xl z-[90] flex flex-col items-center justify-center gap-10 transition-all duration-800 ease-[cubic-bezier(0.16,1,0.3,1)] md:hidden ${
          mobileMenuOpen ? 'opacity-100 translate-y-0' : 'opacity-0 -translate-y-full pointer-events-none'
        }`}
      >
        {['Work', 'Shorts', 'Contact'].map((item) => (
          <button
            key={item}
            onClick={() => scrollToSection(item.toLowerCase())}
            className="text-4xl font-bold text-white/50 hover:text-white transition-all"
          >
            {item}
          </button>
        ))}
      </div>
    </nav>
  );
};

export default Navbar;
