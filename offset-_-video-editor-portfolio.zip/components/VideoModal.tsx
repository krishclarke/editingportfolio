
import React, { useEffect } from 'react';
import { X } from 'lucide-react';

interface VideoModalProps {
  videoUrl: string;
  onClose: () => void;
}

const VideoModal: React.FC<VideoModalProps> = ({ videoUrl, onClose }) => {
  useEffect(() => {
    const handleEsc = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    window.addEventListener('keydown', handleEsc);
    document.body.style.overflow = 'hidden';
    return () => {
      window.removeEventListener('keydown', handleEsc);
      document.body.style.overflow = 'auto';
    };
  }, [onClose]);

  return (
    <div 
      className="fixed inset-0 z-[200] flex items-center justify-center p-4 md:p-10 animate-fade-in"
      onClick={onClose}
    >
      <div className="absolute inset-0 bg-black/95 backdrop-blur-2xl" />
      
      <button 
        onClick={onClose}
        className="absolute top-8 right-8 p-3 glass rounded-full text-white hover:scale-110 active:scale-95 transition-all z-[210]"
      >
        <X size={24} />
      </button>

      <div 
        className="relative w-full max-w-[1200px] aspect-video glass border-none overflow-hidden shadow-2xl animate-scale-up z-[201]"
        onClick={(e) => e.stopPropagation()}
      >
        <iframe 
          src={`${videoUrl}?autoplay=1&mute=0`}
          className="w-full h-full"
          allow="autoplay; fullscreen"
          title="Video Player"
        />
      </div>

      <style>{`
        @keyframes fade-in {
          from { opacity: 0; }
          to { opacity: 1; }
        }
        @keyframes scale-up {
          from { opacity: 0; transform: scale(0.9); }
          to { opacity: 1; transform: scale(1); }
        }
        .animate-fade-in {
          animation: fade-in 400ms ease-out forwards;
        }
        .animate-scale-up {
          animation: scale-up 600ms cubic-bezier(0.16, 1, 0.3, 1) forwards;
        }
      `}</style>
    </div>
  );
};

export default VideoModal;
