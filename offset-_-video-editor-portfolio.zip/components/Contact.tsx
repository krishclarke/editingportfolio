
import React, { useState } from 'react';
import { Mail, Copy, Check, Send } from 'lucide-react';

const Contact: React.FC = () => {
  const [copied, setCopied] = useState(false);
  const [formState, setFormState] = useState({ name: '', email: '', message: '' });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSuccess, setIsSuccess] = useState(false);

  const handleCopyEmail = () => {
    navigator.clipboard.writeText('sequence.create@gmail.com');
    setCopied(true);
    setTimeout(() => setCopied(false), 3000);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    // Simulate API call
    setTimeout(() => {
      setIsSubmitting(false);
      setIsSuccess(true);
      setFormState({ name: '', email: '', message: '' });
      setTimeout(() => setIsSuccess(false), 5000);
    }, 2000);
  };

  return (
    <section id="contact" className="py-32 px-6 md:px-20 max-w-[1440px] mx-auto min-h-screen flex flex-col justify-center">
      <div className="flex flex-col lg:flex-row gap-20 items-start">
        {/* Left Column */}
        <div className="w-full lg:w-[40%] flex flex-col items-start text-left">
          <h2 className="text-[48px] md:text-[56px] font-bold text-textHead leading-tight mb-6">
            Let's Work Together
          </h2>
          <p className="text-[18px] md:text-[21px] text-textBody leading-relaxed mb-12">
            Drop me a line and let's create something awesome. Currently available for new projects.
          </p>

          <div className="flex flex-col gap-8 w-full">
            <div>
              <span className="text-[12px] uppercase font-bold text-textSecondary tracking-[0.2em] block mb-3">
                E-mail
              </span>
              <button 
                onClick={handleCopyEmail}
                className="group glass w-full flex items-center justify-between px-6 py-5 rounded-2xl hover:border-cyan/40 transition-all active:scale-[0.98]"
              >
                <div className="flex items-center gap-4">
                  <div className="w-10 h-10 rounded-xl bg-cyan/10 flex items-center justify-center">
                    <Mail size={20} className="text-cyan" />
                  </div>
                  <span className="text-lg font-mono text-white tracking-tight">
                    sequence.create@gmail.com
                  </span>
                </div>
                <div className="text-cyan group-hover:scale-110 transition-transform">
                  {copied ? <Check size={20} /> : <Copy size={20} className="opacity-40 group-hover:opacity-100" />}
                </div>
              </button>
            </div>

            <p className="text-[14px] text-textSecondary italic">
              More contact options coming soon
            </p>
          </div>
        </div>

        {/* Right Column - Form */}
        <div className="w-full lg:w-[60%]">
          <form 
            onSubmit={handleSubmit}
            className="glass p-8 md:p-12 rounded-[24px] flex flex-col gap-6"
          >
            <div className="flex flex-col gap-2">
              <label className="text-[12px] uppercase font-bold text-textSecondary tracking-widest ml-1">
                Name
              </label>
              <input 
                type="text" 
                required
                placeholder="John Doe"
                value={formState.name}
                onChange={(e) => setFormState({...formState, name: e.target.value})}
                className="bg-white/5 border border-white/10 rounded-xl px-5 py-4 text-white placeholder:text-textSecondary focus:border-cyan/50 focus:outline-none transition-all"
              />
            </div>

            <div className="flex flex-col gap-2">
              <label className="text-[12px] uppercase font-bold text-textSecondary tracking-widest ml-1">
                Email
              </label>
              <input 
                type="email" 
                required
                placeholder="john@example.com"
                value={formState.email}
                onChange={(e) => setFormState({...formState, email: e.target.value})}
                className="bg-white/5 border border-white/10 rounded-xl px-5 py-4 text-white placeholder:text-textSecondary focus:border-cyan/50 focus:outline-none transition-all"
              />
            </div>

            <div className="flex flex-col gap-2 relative">
              <label className="text-[12px] uppercase font-bold text-textSecondary tracking-widest ml-1">
                Message
              </label>
              <textarea 
                required
                rows={5}
                placeholder="Tell me about your project..."
                value={formState.message}
                onChange={(e) => setFormState({...formState, message: e.target.value})}
                className="bg-white/5 border border-white/10 rounded-xl px-5 py-4 text-white placeholder:text-textSecondary focus:border-cyan/50 focus:outline-none transition-all resize-none"
              />
              <span className="absolute bottom-4 right-5 text-[12px] text-textSecondary">
                {formState.message.length}/500
              </span>
            </div>

            <button 
              type="submit"
              disabled={isSubmitting}
              className={`group glass h-16 rounded-xl flex items-center justify-center gap-3 font-bold transition-all relative overflow-hidden ${
                isSubmitting ? 'cursor-not-allowed' : 'hover:scale-[1.02] hover:border-cyan/40'
              }`}
            >
              {/* Button Filling Effect */}
              <div className="absolute inset-0 bg-cyan scale-x-0 group-hover:scale-x-100 origin-left transition-transform duration-700 ease-[cubic-bezier(0.16,1,0.3,1)]" />
              
              <div className="relative z-10 flex items-center gap-3 group-hover:text-black transition-colors duration-300">
                {isSubmitting ? (
                  <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                ) : isSuccess ? (
                  <>
                    <Check size={20} />
                    <span>Message Sent!</span>
                  </>
                ) : (
                  <>
                    <span>Send Message</span>
                    <Send size={18} className="group-hover:translate-x-1 transition-transform" />
                  </>
                )}
              </div>
            </button>
          </form>
        </div>
      </div>
    </section>
  );
};

export default Contact;
