
import React, { useEffect, useState } from 'react';
import { TOOLS } from '../constants';

const Hero: React.FC = () => {
  const [offset, setOffset] = useState(0);

  useEffect(() => {
    const handleScroll = () => {
      setOffset(window.scrollY);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  // Parallax / Scroll Fade Logic
  const opacity = Math.max(0, 1 - offset / 600);
  const translateY = offset * 0.3;
  const blur = Math.min(12, offset / 50);

  return (
    <section 
      id="hero"
      className="relative min-h-screen flex flex-col items-center justify-center px-6 text-center overflow-hidden py-32"
      style={{ 
        opacity, 
        transform: `translateY(${translateY}px)`,
        filter: `blur(${blur}px)`
      }}
    >
      <div className="w-full max-w-[900px] flex flex-col items-center animate-cascade">
        <span className="text-[11px] font-semibold text-textSecondary uppercase tracking-[0.4em] mb-5 animate-slide-up [animation-delay:1200ms]">
          Video Editor
        </span>
        
        <h1 className="text-[80px] md:text-[140px] font-bold tracking-[-0.05em] leading-[0.85] text-textHead mb-8 flex items-baseline animate-slide-up [animation-delay:1350ms]">
          <span className="text-cyan drop-shadow-[0_0_20px_rgba(6,182,212,0.4)]">.</span>
          Offset
        </h1>

        <p className="text-2xl md:text-[36px] font-medium text-textBody mb-6 animate-slide-up [animation-delay:1500ms]">
          I edit cool videos
        </p>

        <p className="text-[17px] leading-relaxed text-textSecondary max-w-[600px] mb-12 animate-slide-up [animation-delay:1650ms]">
          2 years shaping YouTube commentary, pop culture & finance edits. 
          High-paced storytelling that keeps you hooked.
        </p>

        {/* Software Tools */}
        <div className="flex flex-wrap justify-center gap-5 mb-16 animate-slide-up [animation-delay:1800ms]">
          {TOOLS.map((tool, idx) => (
            <div 
              key={tool.name}
              className="glass w-[72px] h-[72px] rounded-2xl flex items-center justify-center opacity-60 hover:opacity-100 hover:scale-110 hover:border-cyan/30 transition-all duration-400 group relative"
              style={{ transitionDelay: `${idx * 100}ms` }}
            >
              <span className="text-2xl font-bold" style={{ color: tool.color }}>
                {tool.icon.length > 2 ? tool.icon : tool.icon}
              </span>
              <div className="absolute bottom-full left-1/2 -translate-x-1/2 mb-2 px-3 py-1 bg-black/80 backdrop-blur-md rounded-md text-[10px] font-bold text-white opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none whitespace-nowrap">
                {tool.name}
              </div>
            </div>
          ))}
        </div>

        <button 
          onClick={() => document.getElementById('work')?.scrollIntoView({ behavior: 'smooth' })}
          className="group glass relative flex items-center gap-3 px-10 py-4 rounded-full text-white font-semibold transition-all duration-500 hover:border-cyan/60 hover:scale-105 active:scale-95 animate-slide-up [animation-delay:2000ms]"
        >
          <span className="relative z-10">View Work</span>
          <svg className="w-5 h-5 transition-transform group-hover:translate-x-1" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5">
            <path d="M5 12h14M12 5l7 7-7 7" strokeLinecap="round" strokeLinejoin="round"/>
          </svg>
        </button>
      </div>

      {/* Scroll Indicator */}
      <div className="absolute bottom-10 left-1/2 -translate-x-1/2 flex flex-col items-center gap-2 opacity-40 animate-pulse">
        <div className="w-6 h-10 border-2 border-white/20 rounded-full flex justify-center p-1.5">
          <div className="w-1 h-2 bg-white rounded-full animate-bounce" />
        </div>
      </div>

      <style>{`
        @keyframes slide-up {
          from { opacity: 0; transform: translateY(30px); filter: blur(10px); }
          to { opacity: 1; transform: translateY(0); filter: blur(0); }
        }
        .animate-slide-up {
          opacity: 0;
          animation: slide-up 1200ms cubic-bezier(0.16, 1, 0.3, 1) forwards;
        }
      `}</style>
    </section>
  );
};

export default Hero;
