
import React from 'react';
import { PROJECTS } from '../constants';
import ProjectCard from './ProjectCard';
import SectionHeading from './SectionHeading';

interface ProjectsProps {
  onOpenVideo: (url: string) => void;
}

const Projects: React.FC<ProjectsProps> = ({ onOpenVideo }) => {
  return (
    <section id="work" className="py-32 px-6 md:px-20 max-w-[1440px] mx-auto">
      <SectionHeading 
        title="Work" 
        subtitle="High-paced storytelling that keeps you hooked" 
      />

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8 w-full mt-20">
        {PROJECTS.map((project, idx) => (
          <ProjectCard 
            key={project.id} 
            project={project} 
            index={idx}
            onClick={() => onOpenVideo(project.videoUrl)}
          />
        ))}
      </div>
    </section>
  );
};

export default Projects;
