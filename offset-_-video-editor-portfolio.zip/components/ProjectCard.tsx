
import React, { useRef, useState } from 'react';
import { Project } from '../types';

interface ProjectCardProps {
  project: Project;
  index: number;
  onClick: () => void;
}

const ProjectCard: React.FC<ProjectCardProps> = ({ project, onClick }) => {
  const cardRef = useRef<HTMLDivElement>(null);
  const [rotate, setRotate] = useState({ x: 0, y: 0 });

  const handleMouseMove = (e: React.MouseEvent<HTMLDivElement>) => {
    if (!cardRef.current) return;
    const rect = cardRef.current.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;
    
    const centerX = rect.width / 2;
    const centerY = rect.height / 2;
    
    const rotateX = (y - centerY) / 15;
    const rotateY = (centerX - x) / 15;
    
    setRotate({ x: rotateX, y: rotateY });
  };

  const handleMouseLeave = () => {
    setRotate({ x: 0, y: 0 });
  };

  return (
    <div 
      ref={cardRef}
      onMouseMove={handleMouseMove}
      onMouseLeave={handleMouseLeave}
      onClick={onClick}
      className="group relative h-[400px] md:h-[450px] rounded-[24px] overflow-hidden cursor-pointer border-[0.5px] border-white/10 transition-all duration-700 ease-[cubic-bezier(0.16,1,0.3,1)] hover:scale-[1.02] hover:-translate-y-2 hover:border-cyan/40 hover:shadow-[0_20px_60px_rgba(0,0,0,0.95),0_0_50px_rgba(6,182,212,0.18)]"
      style={{
        transform: `perspective(1000px) rotateX(${rotate.x}deg) rotateY(${rotate.y}deg)`
      }}
    >
      {/* Background Image */}
      <img 
        src={project.thumbnail} 
        alt={project.title}
        className="absolute inset-0 w-full h-full object-cover brightness-75 group-hover:scale-110 transition-transform duration-1000 ease-out"
      />

      {/* Gradient Overlay */}
      <div className="absolute inset-0 bg-gradient-to-t from-black via-black/40 to-transparent" />

      {/* Top Details */}
      <div className="absolute top-6 right-6 text-[14px] font-semibold text-cyan/50 tracking-wider">
        {project.number}
      </div>

      {/* Bottom Content */}
      <div className="absolute bottom-0 left-0 w-full p-10 z-10 flex flex-col items-start gap-4">
        <h3 className="text-[32px] font-semibold text-white leading-tight">
          {project.title}
        </h3>
        <p className="text-[17px] text-textBody">
          {project.description}
        </p>
        <span className="px-4 py-2 rounded-full text-[12px] font-bold text-cyan bg-cyan/15 border border-cyan/30 uppercase tracking-wide">
          {project.software}
        </span>
      </div>

      {/* Play Button Overlay */}
      <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
        <div className="w-[72px] h-[72px] rounded-full glass border-2 border-cyan/50 flex items-center justify-center opacity-0 scale-75 group-hover:opacity-100 group-hover:scale-100 transition-all duration-600 ease-[cubic-bezier(0.34,1.56,0.64,1)]">
          <svg className="w-8 h-8 text-white translate-x-1" fill="currentColor" viewBox="0 0 24 24">
            <path d="M8 5v14l11-7z"/>
          </svg>
        </div>
      </div>
    </div>
  );
};

export default ProjectCard;
